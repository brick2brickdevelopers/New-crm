function city_list_dropdown(cityselector){
    cityselector.innerHTML='';
    $.ajax({
        url : locationurl+'/get_cityData',
        type: "GET",
        cache: true,
        dataType: 'json',
        success:function(data){
        cityselector.innerHTML='';
        cityselector.innerHTML='<option value="">Choose Suggestion</option>';
        for(let i = 0; i < data.length ; i++){
        var newoption=document.createElement('option');
        newoption.value = data[i].id;
        newoption.text = data[i].name +' ( ' + data[i].country_code +' ) ';
        cityselector.append(newoption);
        }
        }
    });
}

