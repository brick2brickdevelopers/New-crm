$('.sub-menu ul').hide();
$(".sub-menu a").click(function () {
	$(this).parent(".sub-menu").children("ul").slideToggle("100");
	$(this).find(".rightchevron").toggleClass("bi-chevron-up bi-chevron-down");
});

$(document).ready(function(){
  $('.drop-down__button').click(function(){
    $(this).parent(".drop-down").toggleClass('drop-down--active');
  });
});

$(document).ready(function(){
$('.dropdownop-btn').click(function(){
    $(this).parent(".dropdownop").toggleClass('dropdownopactive');
});
});
