$(document).ready(function() {
        $("body").on("submit", "#form-upload-user", function(e) {
            e.preventDefault();
            var data = new FormData(this);
            $.ajax({
                type: 'POST',
                url: "user/import",
                data: data,
                dataType: 'json',
                contentType: false,
                cache: false,
                processData:false,
//                beforeSend: function() {
//                    $("#btnUpload").prop('disabled', true);
//                    $(".user-loader").show();
//                }, 
                success: function(result) {
                    console.log(result);
                    $("#btnUpload").prop('disabled', false);
                    if($.isEmptyObject(result.error_message)) {
                        $(".result").html(result.success_message);
                    } else {
                        $(".sub-result").html(result.error_message);
                    }
//                    $(".user-loader").hide();
                }
            });
        });
    });