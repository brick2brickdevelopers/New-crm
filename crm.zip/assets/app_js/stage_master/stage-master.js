document.addEventListener("DOMContentLoaded", init_onload);
//URL 
const actionurl = new URL(base_url+'level_stage');

const list_show = document.querySelector('#list_show');

//Form
const form  = document.getElementById('form_submit');
const btnsubmit = document.getElementById('btnsubmit');


function init_onload(){
    data_list_show();
}


function data_list_show(){
    list_show.innerHTML='';
    $.ajax({
        url : actionurl+'/get_allData',
        type: "GET",
        cache: true,
        dataType: 'json',
        success:function(data){
            console.log(data);
            let datarows = '';
            data.forEach(resdata => {
               datarows = createlist(resdata);
               list_show.insertBefore(datarows, list_show.childNodes[0]);
            });
        }
    });
}

//Create list card
function createlist(data){
    const li = document.createElement('li');
    li.setAttribute('class','');
    li.setAttribute('data-rowid',data.stages_id);
    li.innerHTML = li_inner(data);
    return li;
}

//Click to Remove data
function removedata(elm){
    let getid = elm.getAttribute('data-targetid');
    var formData={getid};
    $.ajax({
        url : actionurl+'/remove_Data_by_id',
        type: "GET",
        cache: true,
        data : formData,
        dataType: 'json',
        success:function(resdata){
            if(resdata.status === true){
                var li= document.querySelector("[data-rowid='"+getid+"']");
                li.remove();
            }
        }
    });
}

//Click to Edit data
function editdata(elm){
   var getid = elm.getAttribute('data-targetid');
   fillformbyid(getid);
}
//Click to Reset data
function resetdata(event){
   event.preventDefault();
   var getid = document.getElementById('s_id').value;
   fillformbyid(getid);
}

//Create list card inner 
function li_inner(data){

    
    let buttons='';
    buttons=`<ul class="actionbutton">
                <li><button onclick="editdata(this)" type="button" data-targetid="${data.stages_id}" data-toggle="modal" data-target="#modal-lg"><i class="bi bi-pencil"></i>Edit</button></li>
                <li><button onclick="removedata(this)" data-targetid="${data.stages_id}"><i class="bi bi-trash"></i>Delete</button></li>
             </ul>`;
    var divelm='';
    divelm =`
            <div class="tdiv">${data.stage_title}</div>
            <div class="tdiv"><div style="background-color:${data.stage_color};padding:2px 5px;width:100%;"></div></div>
            <div class="tdiv">${data.createdatetime}</div>
            <div class="tdiv">${data.user_name}</div>
            <div class="tdiv"> ${data.ul_title}</div>
            <div class="tdiv">${buttons}</div>
            `;
    
    return divelm;
}

function submitaction(event){
    event.preventDefault();
    var s_id = document.getElementById('s_id').value;
    var formData = new FormData(form);
    $.ajax({
        type: 'POST',
        url:actionurl,
        data:formData,
        processData:false,
        contentType:false,
        async: true,
        dataType: 'json',
        beforeSend: function() { 
                    btnsubmit.setAttribute('disabled', true);
                    btnsubmit.innerHTML='Please Wait..';
                },
        success: function(data){
            console.log(data);
                $('div.form-group').find('.error_show').remove();
                if(data.success === true){
                if(data.messages.status === true){
                        close_modal();
                        form_hide('modal-lg');
                if(s_id!==''){
                    update_set(s_id,'update_row');
                }else{
                    update_set(data.messages.lastid,'update_list');
                }
                        messageFun(data.messages.text,data.messages.type,'<i class="icon ion-ios-alert"></i>');
                }else{
                        messageFun(data.messages.text,data.messages.type,'<i class="icon ion-ios-alert"></i>');
                }
                }else{
                    $.each(data.messages,function(key,val){
                    var element = $('#' + key);
                    element.closest('div.form-group').find('.error_show').remove();
                    element.after(val);
                    });
                }
                
                btnsubmit.removeAttribute('disabled', false);
                document.getElementById('mod_title').innerHTML='Add Branch';
                btnsubmit.innerHTML='Save';
            }
        
    });
}

function fillformbyid(getid){
    var formData={getid};
    $.ajax({
        url : actionurl+'/get_Data_by_id',
        type: "GET",
        cache: true,
        data : formData,
        dataType: 'json',
        success:function(resdata){
            console.log(resdata);
            document.getElementById('s_id').value=resdata.stages_id;
            document.getElementById('stagetitle').value=resdata.stage_title;
            document.getElementById('stagecolor').value=resdata.stage_color;
            document.getElementById('mod_title').innerHTML='Edit Stage';
            btnsubmit.innerHTML='Update';
        }
    });
}

//Funtion for auto set data
function update_set(getid,type){
    var formData={getid};
    $.ajax({
        url : actionurl+'/get_Data_by_id',
        type: "GET",
        cache: true,
        data : formData,
        dataType: 'json',
        success:function(resdata){
            if(type==='update_list'){
                let listtag = '';
                listtag = createlist(resdata);
                list_show.insertBefore(listtag, list_show.childNodes[0]);
            }
            
            if(type==='update_row'){
                var li= document.querySelector("[data-rowid='"+getid+"']");
                li.innerHTML=li_inner(resdata);
            }
            
            
        }
    });
}

function close_modal(){
    form.reset();
    document.getElementById('mod_title').innerHTML='Add Stage';
    btnsubmit.innerHTML='Save';
}