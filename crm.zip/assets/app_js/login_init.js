const login_form  = document.getElementById('login_form');
const login_btn = document.getElementById('login_btn');


function submitaction(event){
        event.preventDefault();
        var formaddaction = login_form.getAttribute('action');
        var formData = new FormData(login_form);
        $.ajax({
            type: 'POST',
            url: formaddaction,
            data:formData,
            processData:false,
            contentType:false,
            async: true,
            dataType: 'json',
            beforeSend: function() { 
                    login_btn.setAttribute('disabled', true);
                    login_btn.innerHTML='Please Wait..';
                },
            success: function(data){
                $('div.input-group').find('.error_show').remove();
                if(data.success === true){
                    if(data.messages.status === true){
                        login_form.reset();
                        messageFun(data.messages.text,data.messages.type,'<i class="icon ion-ios-alert"></i>');                        
                        setTimeout(function(){ window.location.href = "dashboard";}, 2000);
                    }else{
                        messageFun(data.messages.text,data.messages.type,'<i class="icon ion-ios-alert"></i>');
                    }
                }else{
                    $.each(data.messages,function(key,val){
                    var element = $('#' + key);
                    element.closest('div.input-group').find('.error_show').remove();
                    element.after(val);
                    });
                }
                
                login_btn.removeAttribute('disabled', false);
                login_btn.innerHTML='Login';
            }
        });
}