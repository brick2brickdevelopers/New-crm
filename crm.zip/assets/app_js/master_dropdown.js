function branch_list_dropdown(selector){
    selector.innerHTML='';
    $.ajax({
        url : branchurl+'/get_allData',
        type: "GET",
        cache: true,
        dataType: 'json',
        success:function(data){
        selector.innerHTML='';
        selector.innerHTML='<option value="">Choose branch</option>';
        for(let i = 0; i < data.length ; i++){
        var newoption=document.createElement('option');
        newoption.value = data[i].br_id;
        newoption.text = data[i].branch_name;
        selector.append(newoption);
        }
        }
    });
}

function role_list_dropdown(selector){
    selector.innerHTML='';
    $.ajax({
        url : rolesurl+'/get_allData',
        type: "GET",
        cache: true,
        dataType: 'json',
        success:function(data){
        selector.innerHTML='';
        selector.innerHTML='<option value="">Choose Role</option>';
        for(let i = 0; i < data.length ; i++){
        var newoption=document.createElement('option');
        newoption.value = data[i].ul_rowid;
        newoption.text = data[i].ul_title;
        selector.append(newoption);
        }
        }
    });
}