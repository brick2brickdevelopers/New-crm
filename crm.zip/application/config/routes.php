<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'base';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

//Dashboard routes
$route['dashboard'] = 'base/dashboard';

//Masters
$route['branch-master'] = 'base/branch_master';
$route['user-master'] = 'base/users_master';
$route['product-master'] = 'base/product_master';
$route['level-master'] = 'base/steps_master';
$route['leads-operation'] = 'base/leads_ops';
$route['user/import']      = 'Upload/import';

//Logout
$route['logout'] = 'auth/logout';
