<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class City_Controller extends MY_Controller {
    
        public function __construct()
        {
            parent::__construct();
            $this->load->model('location_model');
        }
        
        public function get_cityData(){
//            $data=array('message'=>'hellow');
            $data=$this->location_model->getCityData();
            echo json_encode($data);
        }
    
}