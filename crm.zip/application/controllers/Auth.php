<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends MY_Controller {
        public function __construct()
	{
		parent::__construct();
                $this->load->model('login_model');
	}
        
        public function index()
	{
            $this->isLoggedIn();
            $data = array('success'=>false,'messages'=>array());
            $this->form_validation->set_rules('email_id', 'Email Id', 'trim|required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim|required');
            $this->form_validation->set_error_delimiters('<p class="error_show">','</p>');
            if($this->form_validation->run()) {
                    // If Validation True
                $data['success'] = true; //Message Success True
                
                $emailid = $this->input->post('email_id',TRUE);
                $pass = $this->input->post('password',TRUE);
                
                $logindata = array(
                            'email_id' => $emailid,
                            'password' => $pass,
                        );
                $logeddinresult = $this->login_model->login($logindata);
                if(!empty($logeddinresult)){
                    $sessionArray = array(
                                        'userREGId' => $logeddinresult->acc_id,
                                        'userROLE' => $logeddinresult->user_level,
                                        'userTYPE' => $logeddinresult->user_level,
                                        'userNAME' => $logeddinresult->user_name,
                                        'isLogged_In' => TRUE
                                        );
                    $this->session->set_userdata($sessionArray);
                    $data['messages']['status']=true;
                    $data['messages']['text']='Successfully Logged In';
                    $data['messages']['type']='success';
                }else{
                    $data['messages']['status']=false;
                    $data['messages']['text']='Please check email Id or password';
                    $data['messages']['type']='danger';
                }
            }else{
                
           $dataPost=$this->input->post();
           foreach ($dataPost as $key => $values){
                $data['messages'][$key]=form_error($key);
                }
            }
            
            echo json_encode($data);
        }
}
