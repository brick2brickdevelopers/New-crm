<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Projects extends MY_Controller {
    public function __construct()
	{
		parent::__construct();
                $this->load->model('project_model');
	}
        
        public function index(){
            
            $data = array('success'=>false,'messages'=>array());
            $this->form_validation->set_rules('selectcity', 'Select City', 'trim|required');
            $this->form_validation->set_rules('projecttitle', 'Project Title', 'trim|required');
            
            $this->form_validation->set_error_delimiters('<p class="error_show">','</p>');
            if($this->form_validation->run()) {
            
            // If Validation True
            $data['success'] = true; //Message Success True
            
            $id=$this->input->post('s_id');
            
            $selectcity=$this->input->post('selectcity');
            $projecttitle=$this->input->post('projecttitle');
            
            $formdata = array(
                        'city_id' => $selectcity,
	        	'project_title' => $projecttitle,
            );
            
            if(!empty($id)){
                $formdataup = array(
                        'updater_id'=>$this->session->userdata('userREGId'),
                        'updater_role'=>$this->session->userdata('userROLE'),
                        'update_date'=>date('Y-m-d h:i:s', time()),
	        	);
                
                $formdata=array_merge($formdata,$formdataup);
                $query = $this->project_model->update($formdata, $id);
                $data['messages']['lastid']=$id;
                $data['messages']['text']="Branch Updated";
            }else{
                $formdatain = array('creater_id'=>$this->session->userdata('userREGId'),
                        'creater_role'=>$this->session->userdata('userROLE'),
                        'created_at'=>date('Y-m-d h:i:s', time()),
	        	);
                $formdata=array_merge($formdata,$formdatain);
                $query = $this->project_model->insert($formdata);
                $data['messages']['lastid']=$query;
                $data['messages']['text']="Branch Saved";
            }
            
            if(!empty($query)){
                $data['messages']['type']="success";
                $data['messages']['status']=true;
            }else{
                $data['messages']['status']=false;
                $data['messages']['text']="Something went wrong!";
                $data['messages']['type']="danger";
            }
            
            
            }else{
                
           $dataPost=$this->input->post();
           foreach ($dataPost as $key => $values){
                $data['messages'][$key]=form_error($key);
                }
            }
            
            echo json_encode($data); 		
	}
        
        function get_allData(){
            $data=array();
            $response = $this->project_model->getData();
            
//city_id
//created_at
//creater_id
//creater_role
//
//
//update_date
//updater_id
//updater_role
            
            
            
            foreach($response as $res){
                $data[]=array(
                    'pro_id'=>$res['pro_id'],
                    'city_id'=>$res['city_id'],
                    'project_title'=>$res['project_title'],
                    'user_name'=>$res['user_name'],
                    'ul_title'=>$res['ul_title'],
                    'datetime'=>date("d M g:i a",strtotime($res['created_at'])),
                );
            }
            
            echo json_encode($data);
        }
        
        function get_Data_by_id(){
            $data=array();
            $id=$this->input->get('getid');
            $res = $this->project_model->get_Data_by_id($id);
            $data['pro_id'] = $res->pro_id;
            $data['project_title'] = $res->project_title;
            $data['city_id'] = $res->city_id;
            $data['created_at'] = $res->created_at;
            $data['user_name'] = $res->user_name;
            $data['ul_title'] =  $res->ul_title;    
            $data['datetime'] = date("d M g:i a",strtotime($res->created_at));
            echo json_encode($data);
        }
        
        function remove_Data_by_id(){
            $id=$this->input->get('getid');
            $response = $this->project_model->remove($id);
            if(!empty($response)){
                $data['type']="success";
                $data['status']=true;
            }else{
                $data['type']="danger";
                $data['status']=false;
            }
            echo json_encode($data);
        }
}
