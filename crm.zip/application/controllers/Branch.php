<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Branch extends MY_Controller {
    public function __construct()
	{
		parent::__construct();
                $this->load->model('branch_model');
	}
        
        public function index(){
            
            $data = array('success'=>false,'messages'=>array());
            $this->form_validation->set_rules('branch_name', 'Branch Name', 'trim|required');
            $this->form_validation->set_rules('branch_code', 'Branch Code', 'trim|required');
            $this->form_validation->set_rules('branch_address', 'Branch Address', 'required');
            
            $this->form_validation->set_error_delimiters('<p class="error_show">','</p>');
            if($this->form_validation->run()) {
            
            // If Validation True
            $data['success'] = true; //Message Success True
            
            $id=$this->input->post('s_id');
            
            $branchname=$this->input->post('branch_name');
            $branchcode=$this->input->post('branch_code');
            $branchaddress=$this->input->post('branch_address');
            
            $formdata = array(
                        'branch_name' => $branchname,
	        	'branch_code' => $branchcode,
                        'branch_address' => $branchaddress,
                        'creater_id'=>$this->session->userdata('userREGId'),
                        'creater_role'=>$this->session->userdata('userROLE'),
                        'created_at'=>date('Y-m-d H:i:s', time()),
	        	);
            if(!empty($id)){
                $query = $this->branch_model->update($formdata, $id);
                $data['messages']['lastid']=$id;
                $data['messages']['text']="Branch Updated";
            }else{
                $query = $this->branch_model->insert($formdata);
                $data['messages']['lastid']=$query;
                $data['messages']['text']="Branch Saved";
            }
            
            if(!empty($query)){
                $data['messages']['type']="success";
                $data['messages']['status']=true;
            }else{
                $data['messages']['status']=false;
                $data['messages']['text']="Something went wrong!";
                $data['messages']['type']="danger";
            }
            
            
            }else{
                
           $dataPost=$this->input->post();
           foreach ($dataPost as $key => $values){
                $data['messages'][$key]=form_error($key);
                }
            }
            
            echo json_encode($data); 		
	}
        
        function get_allData(){
            $data=array();
            $response = $this->branch_model->getData();
            foreach($response as $res){
                $data[]=array(
                    'br_id'=>$res['br_id'],
                    'branch_name'=>$res['branch_name'],
                    'branch_code'=>$res['branch_code'],
                    'branch_address'=>$res['branch_address'],
                    'creater_id'=>$res['creater_id'],
                    'creater_role'=>$res['creater_role'],
                    'created_at'=>$res['created_at'],
                    'user_name'=>$res['user_name'],
                    'ul_title'=>$res['ul_title'],
                    'datetime'=>date("d M g:i a",strtotime($res['created_at'])),
                );
            }
            
            echo json_encode($data);
        }
        
        function get_Data_by_id(){
            $data=array();
            $id=$this->input->get('getid');
            $res = $this->branch_model->get_Data_by_id($id);
            $data['br_id'] = $res->br_id;
            $data['branch_name'] = $res->branch_name;
            $data['branch_code'] = $res->branch_code;
            $data['branch_address'] = $res->branch_address;
            $data['creater_id'] = $res->creater_id;
            $data['creater_role'] = $res->creater_role;
            $data['created_at'] = $res->created_at;
            $data['user_name'] = $res->user_name;
            $data['ul_title'] =  $res->ul_title;    
            $data['datetime'] = date("d M g:i a",strtotime($res->created_at));
            echo json_encode($data);
        }
        
        function remove_Data_by_id(){
            $id=$this->input->get('getid');
            $response = $this->branch_model->remove($id);
            if(!empty($response)){
                $data['type']="success";
                $data['status']=true;
            }else{
                $data['type']="danger";
                $data['status']=false;
            }
            echo json_encode($data);
        }
}
