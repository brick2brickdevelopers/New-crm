<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Level_Stage extends MY_Controller {
    public function __construct()
	{
		parent::__construct();
                $this->load->model('stages_model');
	}
        
        public function index(){
            
            $data = array('success'=>false,'messages'=>array());
            $this->form_validation->set_rules('stagetitle', 'Stage Title', 'trim|required');
            $this->form_validation->set_rules('stagecolor', 'Stage Color Code', 'trim|required');
            
            $this->form_validation->set_error_delimiters('<p class="error_show">','</p>');
            if($this->form_validation->run()) {
            
            // If Validation True
            $data['success'] = true; //Message Success True
            
            $id=$this->input->post('s_id');
            
            $stagetitle=$this->input->post('stagetitle');
            $stagecolor=$this->input->post('stagecolor');
            
            $formdata = array(		
                        'stage_title' => $stagetitle,
	        	'stage_color' => $stagecolor,
                        'stage_createrid'=>$this->session->userdata('userREGId'),
                        'stage_createrole'=>$this->session->userdata('userROLE'),
                        'stage_createdat'=>date('Y-m-d H:i:s', time()),
	        	);
            if(!empty($id)){
                $query = $this->stages_model->update($formdata, $id);
                $data['messages']['lastid']=$id;
                $data['messages']['text']="Branch Updated";
            }else{
                $query = $this->stages_model->insert($formdata);
                $data['messages']['lastid']=$query;
                $data['messages']['text']="Branch Saved";
            }
            
            if(!empty($query)){
                $data['messages']['type']="success";
                $data['messages']['status']=true;
            }else{
                $data['messages']['status']=false;
                $data['messages']['text']="Something went wrong!";
                $data['messages']['type']="danger";
            }
            
            
            }else{
                
           $dataPost=$this->input->post();
           foreach ($dataPost as $key => $values){
                $data['messages'][$key]=form_error($key);
                }
            }
            
            echo json_encode($data); 		
	}
        
        function get_allData(){
            $data=array();
            $response = $this->stages_model->getData();
            foreach($response as $res){
                $data[]=array(
                    'stages_id'=>$res['stages_id'],
                    'stage_title'=>$res['stage_title'],
                    'stage_color'=>$res['stage_color'],
                    'stage_status'=>$res['stage_status'],
                    'stage_createrid'=>$res['stage_createrid'],
                    'stage_createrole'=>$res['stage_createrole'],
                    'user_name'=>$res['user_name'],
                    'ul_title'=>$res['ul_title'],
                    'createdatetime'=>date("d M g:i a",strtotime($res['stage_createdat'])),
                );
            }
            
            echo json_encode($data);
        }
        
        function get_Data_by_id(){
            $data=array();
            $id=$this->input->get('getid');
            $res = $this->stages_model->get_Data_by_id($id);
            $data['stages_id'] = $res->stages_id;
            $data['stage_title'] = $res->stage_title;
            $data['stage_color'] = $res->stage_color;
            $data['stage_status'] = $res->stage_status;
            $data['stage_createrid'] = $res->stage_createrid;
            $data['stage_createrole'] = $res->stage_createrole;
            $data['user_name'] = $res->user_name;
            $data['ul_title'] =  $res->ul_title;  
            $data['createdatetime'] = date("d M g:i a",strtotime($res->stage_createdat));
            echo json_encode($data);
        }
        
        function remove_Data_by_id(){
            $id=$this->input->get('getid');
            $response = $this->stages_model->remove($id);
            if(!empty($response)){
                $data['type']="success";
                $data['status']=true;
            }else{
                $data['type']="danger";
                $data['status']=false;
            }
            echo json_encode($data);
        }
}
