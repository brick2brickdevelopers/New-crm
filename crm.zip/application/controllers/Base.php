<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Base extends MY_Controller {
        public function __construct()
	{
		parent::__construct();
	}
        
        public function index()
	{
                $this->isLoggedIn();
		$data['page_title']='Login';
                $data['inject_js']=['login_init'];
                $data['pages']=['base/index'];
                $this->render_base($data);
	}
        
        public function dashboard(){
            if($this->session->userdata('userTYPE')==1){
                $data['page_title']='Dashboard';
                $data['inject_js']=[''];
                $data['pages']=['base/dashboard'];
                $this->render_base($data);
            }else{
                $this->logout();
            }
        }
       

        public function branch_master(){
            if($this->session->userdata('userTYPE')==1){
                $data['page_title']='Branch Master';
                $data['inject_js']=['branch_master/branch-master'];
                $data['pages']=['base/branch_master/branch_master','base/branch_master/branch_form'];
                $this->render_base($data);
            }else{
                $this->logout();
            }
        }
        
        public function steps_master(){
            if($this->session->userdata('userTYPE')==1){
                $data['page_title']='Stage Level Mater';
                $data['inject_js']=['stage_master/stage-master'];
                $data['pages']=['base/stage_master/stage_master','base/stage_master/stage_form'];
                $this->render_base($data);
            }else{
                $this->logout();
            }
        }
        
        public function leads_ops(){
            if($this->session->userdata('userTYPE')==1){
                $data['page_title']='Leads Operations';
                $data['inject_js']=['lead_upload/lead_upload'];
                $data['pages']=['base/leads_ops'];
                $this->render_base($data);
            }else{
                $this->logout();
            }
        }

        public function users_master(){
            if($this->session->userdata('userTYPE')==1){
                $data['page_title']='User Master';
                $data['inject_js']=['user_master/user-master','master_dropdown'];
                $data['pages']=['base/user_master/user_master','base/user_master/user_form'];
                $this->render_base($data);
            }else{
                $this->logout();
            }
        }
        
        public function product_master(){
            if($this->session->userdata('userTYPE')==1){
                $data['page_title']='Product Master';
                $data['inject_js']=['product_master/product_master','city'];
                $data['pages']=[
                    'base/project_master/project_form',
                    'base/project_master/project_master'];
                $this->render_base($data);
            }else{
                $this->logout();
            }
        }
        
        
}
