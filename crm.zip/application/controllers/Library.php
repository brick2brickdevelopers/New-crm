<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Library extends MY_Controller {
        public function __construct()
	{
		parent::__construct();
                $this->load->model('operation_model');
                $this->load->model('library_model');
	}
        
	
	public function index()
	{

		$data['page_title']=  'Serach Books';
                $data['sessiondata']=$this->session->userdata();
                $data['inject_js']=['library/all_books'];
                $tablename='accession_detail';
                $selectvalue1=['distinct(author)'];
                $data['accession_data'] = $this->operation_model->getallList_withfield($tablename,$selectvalue1);
                
                $selectvalue2=['distinct(publication)'];
                $data['publication_data'] = $this->operation_model->getallList_withfield($tablename,$selectvalue2);
                $this->render_base('library/index', $data);
	}
        
        public function show_all_books(){
            $tablename='accession_detail';
            $select_value = $this->input->post('conditiontitle',TRUE);
            $select_field = $this->input->post('conditionfield',TRUE);
            
            if(!empty($select_value)){
            $accession_data = $this->operation_model->get_allrecord_by_field($tablename,$select_field,$select_value);
            }else{
            $orderfieldname='book_title_no';
            $orderbycon='DESC';
            $accession_data = $this->operation_model->getallList($tablename,$orderfieldname,$orderbycon);
            }
            
            
            
            $html='';
            $html.='<table id="dt_activitymaster" cellspacing="0" class="table table-bordered table-wrapper table-striped w-100">
                        <thead>
                        <tr>
                        <th class="fs-12">S. No.</th>
                        <th class="fs-12">Book Title</th>
                        <th class="fs-12">Author</th>
                        <th class="fs-12">Publication</th>
                        <th class="fs-12">Edition</th>
                        <th class="fs-12">Total Remaining </th>
                        <th class="fs-12">Issued Books</th>
                        <th class="fs-12">Total Books</th>
                        </tr>
                        </thead>
                        <tbody>';
                  
                  if(!empty($accession_data)){
                  $i = 1;
                  foreach($accession_data as $row){

                      
                    $html.='<tr>
                          <td class="fs-12">'.$i++.' .</td>
                          <td class="fs-12">'. $row['book_title'].'</td>
                          <td class="fs-12">'. $row['author'].'</td>
                          <td class="fs-12">'. $row['publication'].'</td>
                          <td class="fs-12">'. $row['edition'].'</td>
                          <td class="fs-12">'. $row['total_remaining_book'].'</td>
                          <td class="fs-12">'. $row['total_book_issued'].'</td>
                          <td class="fs-12">'. $row['total_no_of_book'].'</td>
                            </tr>';  
                  }
                  }
                    $html.='</tbody>
                            </table> ';
 
                        echo $html;

                            }
        
      public function issue_books(){
                $data['page_title']=  'Issue Books';
                $data['sessiondata']=$this->session->userdata();
                $data['inject_js']=['library/issue_books'];
                $this->render_base('library/issue_books', $data);
      }  
      
      public function return_books(){
                $data['page_title']=  'Return Books';
                $data['sessiondata']=$this->session->userdata();
                $data['inject_js']=['library/return_books'];
                $this->render_base('library/return_books', $data);
      }
      
      
      
      
      
      // Function Are There
      public function ajaxstudentsearch()
    {
        if (isset($_POST['search_data'])) {
                $title=$_POST['search_data'];
                $table='student_reg';
                $field='sname';

                $result = $this->operation_model->search_like($table,$field,$title);
                if (count($result) > 0) {
                $view = '';
                foreach ($result as $row)
                $view = $view .'<li class="selectedstudent" data-sturollnumber="'.$row->roll_no.'" data-stuname="'.$row->sname.'">'.$row->sname.'</li>';
                }else{
               $view = '';
                }
                echo $view;
        }
    }
    
    public function ajaxbooksearch()
    {
        if (isset($_POST['search_data'])) {
                $title=$_POST['search_data'];
                $table='accession_detail';
                $field='book_title';

                $result = $this->operation_model->search_like($table,$field,$title);
                if (count($result) > 0) {
                $view = '';
                foreach ($result as $row)
                $view = $view .'<li class="selectedbook" data-booknoid="'.$row->book_title_no.'" data-bookname="'.$row->book_title.'">'.$row->book_title.'</li>';
                }else{
                $view = '<li><em>No Found... </em></li>';
                }
                echo $view;
        }
    }
    
    public function studentlibrarydata(){
          $studentdatarollnumber=$this->input->post('studentdatarollnumber');
          
          //Student Personal Record
          $data['maindata'] = $this->operation_model->get_record_by_id('student_reg',['sname','sid','roll_no'],'roll_no',$studentdatarollnumber);
          
          //Student Library Data

          $data['librarydata'] = $this->operation_model->get_record_by_id('student_library_record',['no_of_book_permitted','no_of_book_issued'],'student_rollno',$studentdatarollnumber);
          
          echo json_encode($data);
    }
    
    public function studentprevissueddata(){
        $studentdatarollnumber=$this->input->post('studentdatarollnumber');
        //Student Library Data

        $libraryissuedbook = $this->operation_model->get_allrecord_by_field('lib_book_issue_return','issued_to',$studentdatarollnumber);
        $html='';
        $html.='<table id="dt_activitymaster" cellspacing="0" class="table table-striped w-100">
                    <thead>
                    <tr>
                    <th class="fs-12">S. No.</th>
                    <th class="fs-12">Book Title</th>
                    <th class="fs-12">Issue Date</th>
                    <th class="fs-12">Return Date</th>
                    <th class="fs-12">Action</th>
                    </tr>
                    </thead>
                    <tbody>';
         if(!empty($libraryissuedbook)){
                  $i = 1;
                  foreach($libraryissuedbook as $libraryissuedbooklist){
                   $bookid = $libraryissuedbooklist['accession_book_id'];
                   $table_acc_booksstock='accession_books';
                   $wheredataacc_book = array('accession_book_id'=>$bookid);
                   $checkresult=$this->library_model->select_fetch($wheredataacc_book,$table_acc_booksstock);   
                    $html.='<tr>
                          <td class="fs-12">'.$i++.' .</td>
                          <td class="fs-12">'. $checkresult['book_title'].'</td>
                          <td class="fs-12">'. date("d-m-Y",strtotime($libraryissuedbooklist['date_of_issue'])).'</td>
                          <td class="fs-12">'. date("d-m-Y",strtotime($libraryissuedbooklist['date_of_return'])).'</td>
                          <td class="fs-12"><button class="retrun_book btn btn-sm btn-danger " id="'.$bookid.'">Return Book</button></td>
                         </tr>';  
                  }
                  }else{
                      $html.='<tr>
                                <td class="fs-12 text-center" colspan="5">No Book Issue</td>
                              </tr>';
                  }
       
        $html.='</tbody>
                            </table> ';
 
                        echo $html;
    }
    
    
    
    public function booklibrarydata(){
          $booknodataid=$this->input->post('booknodataid');
          $data['mainbookdata'] = $this->operation_model->get_record_by_id('accession_detail',['*'],'book_title_no',$booknodataid);
          echo json_encode($data);
    }
    
 
    // Finally Issue Book
    
    public function book_issue_function(){
        $book_idaccessionnum=$this->input->post('book_id');
        $issued_torollnum=$this->input->post('issued_to');
        
        $formissuebook=array();
                
        $formissuebook['bookacc_id'] = $book_idaccessionnum;
        $formissuebook['issuedtorollno'] = $issued_torollnum;
        
        $libraryissuebook = $this->library_model->issuebook($formissuebook);
        
        print_r($libraryissuebook);
        
    }
    
    // Finally Return Book
    public function return_book(){
            $bookrow_id=$this->input->post('booknodataid');
            
            $libraryreturnbook = $this->library_model->returnbook($bookrow_id);
            print_r($libraryreturnbook);
    }
       
        
}


   
//    public function acclibrarydata(){
//        $tablename='accession';
//        $selectvalue='book_title_no,author,book_title,edition,publication';
//        $result = $this->operation_model->getallList_withfield($tablename,$selectvalue);
//        $tablename1='accession_books';
//        foreach($result as $rs){
//            $formarray=array();
//            $formarray['accession_detail_id'] = $rs['book_title_no'];
//            $formarray['author'] = $rs['author'];
//            $formarray['book_title'] = $rs['book_title'];
//            $formarray['edition'] = $rs['edition'];
//            $formarray['publication'] = $rs['publication'];
//            $result = $this->operation_model->insert_all($formarray,$tablename1);
//            
//        }
//    }
