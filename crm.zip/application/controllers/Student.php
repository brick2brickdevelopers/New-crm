<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends MY_Controller {
        public function __construct()
	{
		parent::__construct();
                $this->load->model('login_model');
	}
        
	
	public function index()
	{
                $this->isLoggedIn();
		$data['page_title']=  'Login Library';
                $this->render_base('library/index', $data);
	}
        
        
       
        
}