<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends MY_Controller {
    public function __construct()
	{
		parent::__construct();
                $this->load->model('user_model');
	}
        
        public function index(){
            
            $data = array('success'=>false,'messages'=>array());
            $this->form_validation->set_rules('selectbranch', 'Branch', 'trim|required'); 
            $this->form_validation->set_rules('selectrole', 'Role', 'trim|required'); 
            $this->form_validation->set_rules('username', 'Name', 'trim|required'); 
            $this->form_validation->set_rules('usermail', 'Email', 'trim|required|min_length[6]|max_length[50]|valid_email|is_unique[users.ur_email]'); 
            $this->form_validation->set_rules('usercon', 'Contact number', 'trim|required|min_length[10]|max_length[15]|is_unique[users.ur_contact]');
            $this->form_validation->set_rules('joindate', 'Join date', 'trim|required');
            $this->form_validation->set_error_delimiters('<p class="error_show">','</p>');
            if($this->form_validation->run()) {
            
            // If Validation True
            $data['success'] = true; //Message Success True
            
            $selectbranch=$this->input->post('selectbranch');
            $selectrole=$this->input->post('selectrole');
            $username=$this->input->post('username');
            $usermail=$this->input->post('usermail');
            $usercon=$this->input->post('usercon');
            $joindate=$this->input->post('joindate');
            
            $id=$this->input->post('s_id');
            
            
            $formdatauser = array(
                    'ur_name'=>$username,
                    'ur_email'=>$usermail,
                    'ur_contact'=>$usercon,
                    'ur_role'=>$selectrole, 
                    'ur_branch'=>$selectbranch,
                    'ur_branchmanger'=>0,
                    'ur_teamlead'=>0,
                    'ur_createddate'=>date('Y-m-d H:i:s', time()), 
                    'ur_createdby'=>$this->session->userdata('userREGId'), 
                    'ur_createrrole'=>$this->session->userdata('userROLE'), 
                    'ur_joindate'=>$joindate
                );
            if(!empty($id)){
                $query = $this->user_model->update($formdatauser, $id);
                $data['messages']['lastid']=$id;
                $data['messages']['text']="User Record Updated";
            }else{                
                $query = $this->user_model->createUser($formdatauser);
                
                $password= $this->randomPassword();
                $formdata = array(
                'user_name' => $username,
                'user_email' => $usermail,
                'user_password' => password_hash($password,PASSWORD_DEFAULT),
                'main_pwd'=>$password,
                'user_level'=>$selectrole,
                'acc_id'=>$query,
                'acc_createrid'=>$this->session->userdata('userREGId'),
                'acc_createrlevel'=>$this->session->userdata('userROLE'),
                'acc_create_dt'=>date('Y-m-d H:i:s', time()),
                );
                $queryLogin = $this->user_model->createUserLogin($formdata);
                $data['messages']['lastid']=$query;
                $data['messages']['text']="User Record Saved";
            }
            
            if(!empty($queryLogin)){
                $data['messages']['type']="success";
                $data['messages']['status']=true;
            }else{
                $data['messages']['status']=false;
                $data['messages']['text']="Something went wrong!";
                $data['messages']['type']="danger";
            }
            
            
            }else{
                
           $dataPost=$this->input->post();
           foreach ($dataPost as $key => $values){
                $data['messages'][$key]=form_error($key);
                }
            }
            
            echo json_encode($data); 		
	}
        
        function randomPassword() {
            $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789@#";
            $pass = array(); //remember to declare $pass as an array
            $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
            for ($i = 0; $i < 8; $i++) {
                $n = rand(0, $alphaLength);
                $pass[] = $alphabet[$n];
            }
            return implode($pass); //turn the array into a string
        }
        
        function get_allData(){
            $data=array();
            $response = $this->user_model->getData();
//            foreach($response as $res){
//                $data[]=array(
//                    'pro_id'=>$res['pro_id'],
//                    'city_id'=>$res['city_id'],
//                    'project_title'=>$res['project_title'],
//                    'user_name'=>$res['user_name'],
//                    'ul_title'=>$res['ul_title'],
//                    'datetime'=>date("d M g:i a",strtotime($res['created_at'])),
//                );
//            }
            
            echo json_encode($response);
        }
        
        function get_Data_by_id(){
            $data=array();
            $id=$this->input->get('getid');
            $res = $this->project_model->get_Data_by_id($id);
            $data['pro_id'] = $res->pro_id;
            $data['project_title'] = $res->project_title;
            $data['city_id'] = $res->city_id;
            $data['created_at'] = $res->created_at;
            $data['user_name'] = $res->user_name;
            $data['ul_title'] =  $res->ul_title;    
            $data['datetime'] = date("d M g:i a",strtotime($res->created_at));
            echo json_encode($data);
        }
        
        function remove_Data_by_id(){
            $id=$this->input->get('getid');
            $response = $this->project_model->remove($id);
            if(!empty($response)){
                $data['type']="success";
                $data['status']=true;
            }else{
                $data['type']="danger";
                $data['status']=false;
            }
            echo json_encode($data);
        }
}
