<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Kolkata');
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Upload extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		// Load Model
		$this->load->model('Lead_model', 'lead_upload');
		$this->ip_address= $_SERVER['REMOTE_ADDR'];
		$this->datetime= date("Y-m-d H:i:s");
                
//                echo json_encode($this->session->userdata());
	}
	
	public function index() {
	    $this->load->view("index");
	}
	
	public function display() {
    	$data 	= [];
    	$data ["result"] = $this->lead_upload->get_all();
    	$this->load->view("index");
        }
        
        public function import() {
            $datareturn = array('success'=>false,'message'=>array());
            if($_FILES["file"]["name"] != ''){
            $mainfilename=$_FILES["file"]["name"];
            $allowed_extension = array('csv','CSV','xlsx','XLSX','xls','XLS');
            $file_array = explode(".", $mainfilename);
            $file_extension = end($file_array);
                if(in_array($file_extension, $allowed_extension))
                {
                    
                }else{
                    $errors['file'] = 'Only .xls, .csv or .xlsx file allowed.';
                }
            }else{
                    $errors['file'] = 'Please Select Your File.';
            }
            
            
            if (!empty($errors)) {
            $datareturn['success'] = false;
                foreach ($errors as $key => $value){
                    $datareturn['message'][$key]='<span class="leaduploaderror">'.$value.'</span>';
                }
            }else{
                $datareturn['success'] = true;
                $time_start = microtime(true);
                $uplodername = str_replace(' ','_','brick2brick');
                $datareturn['success'] = true;
                $file_name = $uplodername.round($time_start) . '.' . $file_extension;
                move_uploaded_file($_FILES['file']['tmp_name'], $file_name);
                $file_type = \PhpOffice\PhpSpreadsheet\IOFactory::identify($file_name);
                $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($file_type);
                $reader->setReadDataOnly(TRUE);
                $reader->setReadEmptyCells(false);
                $spreadsheet = $reader->load($file_name);
                unlink($file_name);
                $highestColumm = $spreadsheet->setActiveSheetIndex(0)->getHighestColumn();
                $data = $spreadsheet->getActiveSheet()->toArray();
                array_shift($data);
                $data = array_values($data);
                $datacount = COUNT($data); //Count Row

               //Files Save  
                $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, $file_type);
                $writer->save('assets/lead_files/'.$file_name); //Move file in folder
                
                //Save Lead file in Folder and Get Id
                $formdatafile=array(
                'filename'=>$file_name,
                'filerowcount'=>$datacount,
                'file_uploadedby'=>$this->session->userdata('userREGId'),
                'file_uploader_role'=>$this->session->userdata('userROLE'),
                'file_uploaddate'=>date('Y-m-d H:i:s', time()),
                );
                
                $filesrid = $this->lead_upload->insertfile($formdatafile);
                $field=[];
                if(!empty($filesrid)){
                    $field=[
                        'name',
                        'mobile',
                        'other_con',
                        'email',
                        'city',
                        'leadsource',
                        'assignto',
                        'project',
                        'status',
                        'comment',
                        'file_id',
                        'activity',
                        'age',
                        'income',
                        'marital_status',
                        'occupation',
                        'created_at'                        
                        ];
                
                }else{
                    
                }
                
                
                
            }
            
            
            
            
        }
	public function import2() {
		$path 		= 'documents/users/';
		$json 		= [];
		$this->upload_config($path);
		if (!$this->upload->do_upload('file')) {
			$json = [
				'error_message' => $this->upload->display_errors(),
			];
		} else {
			$file_data 	= $this->upload->data();
			$file_name 	= $path.$file_data['file_name'];
			$arr_file 	= explode('.', $file_name);
			$extension 	= end($arr_file);
			if('csv' == $extension) {
				$reader 	= new \PhpOffice\PhpSpreadsheet\Reader\Csv();
			} else {
				$reader 	= new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
			}
			$spreadsheet 	= $reader->load($file_name);
			$sheet_data 	= $spreadsheet->getActiveSheet()->toArray();
			$list 			= [];
			foreach($sheet_data as $key => $val) {
				if($key != 0) {
					$result 	= $this->lead_upload->get(["country_code" => $val[2], "mobile" => $val[3]]);
					if($result) {
					} else {
						$list [] = [
							'name'					=> $val[0],
							'mobile'			=> $val[1],
							'email'				=> $val[2],
							'city'					=> $val[3],
							'created_at' 			=> $this->datetime,
							'status'				=> "1",
						];
					}
				}
			}
			if(file_exists($file_name))
				unlink($file_name);
			if(count($list) > 0) {
				$result 	= $this->lead_upload->add_batch($list);
				if($result) {
					$json = [
						'success_message' 	=> "All Entries are imported successfully.",
					];
				} else {
					$json = [
						'error_message' 	=> "Something went wrong. Please try again."
					];
				}
			} else {
				$json = [
					'error_message' => "No new record is found.",
				];
			}
		}
		echo json_encode($json);
	}

	public function upload_config($path) {
		if (!is_dir($path)) 
			mkdir($path, 0777, TRUE);		
		$config['upload_path'] 		= base_url().$path;		
		$config['allowed_types'] 	= 'csv|CSV|xlsx|XLSX|xls|XLS';
		$config['max_filename']	 	= '255';
		$config['encrypt_name'] 	= TRUE;
		$config['max_size'] 		= 4096; 
		$this->load->library('upload', $config);
	}
}
