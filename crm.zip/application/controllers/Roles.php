<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Roles extends MY_Controller {
    public function __construct()
	{
		parent::__construct();
                $this->load->model('roles_model');
	}
        
        public function get_allData(){
            $response = $this->roles_model->getData();
            echo json_encode($response);
        }
}
?>
