<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
<!--    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
              <h6 class="m-0"><b><?php echo $page_title;?></b></h6>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a class="text-dark" href="<?php echo base_url();?>">Home</a></li>
              <li class="breadcrumb-item active"><?php echo $page_title;?></li>
            </ol>
          </div>
        </div>
      </div>
    </div>-->
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
        <div class="col-12  mt-3">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <div class="d-flex align-items-center justify-content-between">
                <h3 class="card-title"><?php echo $page_title;?></h3>
                <div class="card-tools text-right">
                <button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal-lg">
                  <i class="bi bi-plus-lg"></i>
                </button>
                </div>
                </div>
              </div>
              <div class="card-body">
                        <div class="display-list">
                            <ul>
                                <li>
                                    <div class="trdiv">Name</div>
                                    <div class="trdiv">Code</div>
                                    <div class="trdiv">Address</div>
                                    <div class="trdiv">Status</div>
                                    <div class="trdiv">Action</div>
                                </li>
                            </ul>
                            <ul id="list_show"></ul>
                        </div>
              </div>
              <!-- /.card-body -->
<!--              <div class="card-footer">
                Footer
              </div>-->
              <!-- /.card-footer-->
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
  
  
  
  
