  <div class="modal fade" id="modal-lg" style="display: none;" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
           <form method="post" enctype="multipart/form-data" id="form_submit" onsubmit="submitaction(event,this)" autocomplete="off">
            <div class="modal-header">
              <h4 class="modal-title" id="mod_title">Add Stage</h4>
              <button type="button" onclick="close_modal()" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true" class="bi bi-x-lg"></span>
              </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input type="text" id="s_id" name="s_id" hidden value=""/>
                        <label>Select Branch</label>
                        <select class="form-control select2" id="selectbranch" name="selectbranch">
                            <option value="">Choose Branch</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input type="text" id="s_id" name="s_id" hidden value=""/>
                        <label>Select Role</label>
                        <select class="form-control select2" id="selectrole" name="selectrole">
                            <option value="">Choose Role</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>User Name</label>
                        <input type="text" class="form-control" id="username" name="username" placeholder="Enter User Name">
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>User Email</label>
                        <input type="text" class="form-control" id="usermail" name="usermail" placeholder="Enter User Email">
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>User Contact</label>
                        <input type="text" class="form-control" id="usercon" name="usercon" placeholder="Enter User Contact">
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>User JoinDate</label>
                        <input type="date" class="form-control" id="joindate" name="joindate">
                      </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer w-100 justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-default" onclick="resetdata(event)">Reset</button>
              <button type="submit" class="btn btn-primary" id="btnsubmit">Save</button>
            </div>
           </form>
          </div>
        </div>
 </div>