<div class="modal fade" id="modal-type" tabindex="-1" role="dialog" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content"></div>                
        </div>            
</div>
