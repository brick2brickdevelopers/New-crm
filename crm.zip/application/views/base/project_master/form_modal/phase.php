<div class="modal fade" id="modal-phase" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
              <h4 class="modal-title" id="mod_title">Add Phase</h4>
              <button type="button" onclick="close_modal()" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true" class="bi bi-x-lg"></span>
              </button>
            </div>
            <div class="modal-body">
               
            </div>
            <div class="modal-footer w-100 justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-default" onclick="resetdata(event)">Reset</button>
              <button type="submit" class="btn btn-primary" id="btnsubmit">Save</button>
            </div>
            </div>                
        </div>            
</div>
