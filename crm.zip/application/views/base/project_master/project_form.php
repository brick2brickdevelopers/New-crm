<style>
    .addbtn{
        font-size:12px;
        border:none;
        background:lightblue;
        margin-left:0.5rem;
    }
</style>

<div class="modal fade" id="modal-lg" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
           <form method="post" enctype="multipart/form-data" id="form_submit" onsubmit="submitaction(event,this)" autocomplete="off">
            <div class="modal-header">
              <h4 class="modal-title" id="mod_title">Add Project</h4>
              <button type="button" onclick="close_modal()" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true" class="bi bi-x-lg"></span>
              </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input type="text" id="s_id" name="s_id" hidden value=""/>
                        <label>Select City</label>
                        <select class="form-control select2" id="selectcity" name="selectcity">
                            <option value="">Choose City</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>Project Name</label>
                        <input type="text" class="form-control" id="projecttitle" name="projecttitle" placeholder="Enter Project title">
                      </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer w-100 justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-default" onclick="resetdata(event)">Reset</button>
              <button type="submit" class="btn btn-primary" id="btnsubmit">Save</button>
            </div>
           </form>
          </div>
        </div>
 </div>

