  <div class="modal fade" id="modal-lg" style="display: none;" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
           <form method="post" enctype="multipart/form-data" id="form_submit" onsubmit="submitaction(event,this)" autocomplete="off">
            <div class="modal-header">
              <h4 class="modal-title" id="mod_title">Add Stage</h4>
              <button type="button" onclick="close_modal()" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true" class="bi bi-x-lg"></span>
              </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-6">
                      <!-- text input -->
                      <div class="form-group">
                        <label>Stage Title</label>
                        <input type="text" id="s_id" name="s_id" hidden value=""/>
                        <input type="text" class="form-control" id="stagetitle" name="stagetitle" placeholder="Enter Stage title">
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>Stage Color Code</label>
                        <input type="color" class="form-control" id="stagecolor" name="stagecolor">
                      </div>
                    </div>
                    
                </div>
            </div>
            <div class="modal-footer w-100 justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-default" onclick="resetdata(event)">Reset</button>
              <button type="submit" class="btn btn-primary" id="btnsubmit">Save</button>
            </div>
           </form>
          </div>
        </div>
 </div>