<!-- Main Sidebar Container -->

  <aside class="main-sidebar sidebar-light-light elevation-1">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
        
        <span class="brand-text font-weight-dark">Business CRM</span>
<!--      <img src="<?php echo base_url('assets/img/logo.png');?>" alt="AdminLTE Logo" class="brand-image">
      <span class="brand-text font-weight-dark">Brick2Brick</span>-->
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo base_url('assets/img/user-70-70.jpg');?>" class="img-circle elevation-1" alt="User Image">
        </div>
        <div class="info">
          <a href="<?php echo base_url();?>" class="d-block">User name</a>
        </div>
          
      </div>

      <!-- SidebarSearch Form -->

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
              <a href="<?php echo base_url();?>" class="nav-link">
              <i class="nav-icon bi bi-speedometer2"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          
          <li class="nav-item">
            <a href="<?php echo base_url('branch-master');?>" class="nav-link">
              <i class="nav-icon bi bi-diagram-2"></i>
              <p>
                Branch
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo base_url('level-master');?>" class="nav-link">
              <i class="nav-icon bi bi-bar-chart-steps"></i>
              <p>
                Level Steps
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo base_url('product-master');?>" class="nav-link">
              <i class="nav-icon bi bi-buildings"></i>
              <p>
                Product Master
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo base_url('user-master');?>" class="nav-link">
              <i class="nav-icon bi bi-people"></i>
              <p>
                Users
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo base_url('leads-operation');?>" class="nav-link">
              <i class="nav-icon bi bi-x-diamond"></i>
              <p>
                Leads Operation
              </p>
            </a>
          </li>
<!--       <!--          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon bi bi-buildings"></i>
              <p>
                Projects
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php  echo base_url('product-master');?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Phase</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php  echo base_url('product-master');?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Tower</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php  echo base_url('product-master');?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Facing</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php  echo base_url('product-master');?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Type</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo base_url('product-master');?>" class="nav-link active">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Manage Project</p>
                </a>
              </li>
            </ul>
          </li>   <li class="nav-item menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="./index.html" class="nav-link active">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Dashboard v1</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="./index2.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Dashboard v2</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="./index3.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Dashboard v3</p>
                </a>
              </li>
            </ul>
          </li>-->
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>