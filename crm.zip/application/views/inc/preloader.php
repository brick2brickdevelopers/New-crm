<!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__wobble" src="<?php echo base_url('assets/img/logo.png');?>" alt="CRM Logo" height="60" width="60">
  </div>