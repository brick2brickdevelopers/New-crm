<?php

if (! defined('BASEPATH')) exit ('No Direct Script Access Allowed');

class MY_Controller extends CI_Controller{
     
    public function __construct() {
         parent::__construct();
     }
    
     
    function meta_header($data){
        $this->load->view('inc/meta_header',$data);
    }
    
    function preloader($data){
        $this->load->view('inc/preloader',$data);
    }
    
    function header($data){
        $this->load->view('inc/header',$data);
    }
    
    function sidebar($data){
        $this->load->view('inc/sidebar',$data);
    }
    
    function footer($data){
//        $this->load->view('inc/footer',$data);
    }
     
    function meta_footer($data){
        $this->load->view('inc/meta_footer',$data);
    }
    
   
    public function render_base($data = array()){
        $this->meta_header($data);
        if(!empty($this->session->userdata('isLogged_In'))){
        $this->preloader($data);
	$this->header($data);
        $this->sidebar($data);
        $this->footer($data);
	}else{
              
        }
        foreach($data['pages'] as $page){
            $this->load->view($page, $data);
        }
        $this->meta_footer($data);
    }
    
    public function isLoggedIn(){
//            if(!empty($this->session->userdata('isLogged_In')) || $this->session->userdata('isLogged_In') === true) {
//             return TRUE;
//            }else{
//             return FALSE;       
//            }
    }
    
        public function logged_in()
	{
		$session_data = $this->session->userdata();
		if($session_data['logged_in'] == TRUE) {
			redirect('dashboard', 'refresh');
		}
	}

	public function not_logged_in()
	{
		$session_data = $this->session->userdata();
		if($session_data['logged_in'] == FALSE) {
			redirect('auth/login', 'refresh');
		}
	}
    
    function logout() {
		$this->session->sess_destroy();
		redirect('/');
    }
    
     
 }
