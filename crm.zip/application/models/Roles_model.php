<?php  

class Roles_model extends CI_Model {  
    
    public function __construct() {
        parent::__construct();
        
    }
    
    function getData(){
        $wherearray = array('ul_rowid !=' => 1, 'ul_status !=' => 0, 'ul_deleted !=' => 0);
        $this->db->select('user_level.*');
        $this->db->from('user_level');
        $this->db->where($wherearray);
        $query = $this->db->get();
        $result = $query->result_array();
        return !empty($result) ? $result : false;
    }
}
