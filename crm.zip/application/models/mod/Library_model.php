<?php

 class Library_model extends CI_Model{
    //put your code here
    public function __construct() {
        parent::__construct();
//        $table_acc_booksstock='accession_books';
//        $table_acc_detail='accession_detail';
//        $table_student_issued_book_library_record='student_library_record';
//        $table_lib_book_issue_return = 'lib_book_issue_return';
    }
    
    
    
    //Issue book
    
    function issuebook($formArray=''){
            $acc_detailbook_id=$formArray['bookacc_id'];
            $stu_roll_no=$formArray['issuedtorollno'];
               
//       STEP 1
//       check number of not issued books
            $table_acc_booksstock='accession_books';
            $wheredataacc_book = array('accession_detail_id'=>$acc_detailbook_id,'issued'=>0,'issued_to'=>'');
            
            $checkresult=$this->select_fetch($wheredataacc_book,$table_acc_booksstock);
            $accession_book_id=$checkresult['accession_book_id'];
        
            if($checkresult){
            
//        STEP 2
//        Update issued Book Row
            
            $updatedata = array('issued'=> 1,'issued_to' => $stu_roll_no,'issued_user_type' => 'student');
            $wheredata=array('accession_book_id' => $accession_book_id);
            $updatebook_issue=$this->update_row($table_acc_booksstock,$updatedata,$wheredata);
            
           if($updatebook_issue){
            
            $table_acc_detail='accession_detail';
            $wheredataacc_detail = array('book_title_no'=>$acc_detailbook_id);
            $fetchresultacc_detail=$this->select_fetch($wheredataacc_detail,$table_acc_detail);
               
            $newissuebook = $fetchresultacc_detail['total_book_issued']+1;
            $newremainingbook = $fetchresultacc_detail['total_remaining_book']-1;
            
//            STEP 3
//            UPDATE ACCESSION BOOK DETAIL
            $updatedataforacc_detail = array('total_book_issued'=> $newissuebook,'total_remaining_book' => $newremainingbook);
            $wheredata=array('book_title_no' => $acc_detailbook_id);
            $updateacc_detailupdate=$this->update_row($table_acc_detail,$updatedataforacc_detail,$wheredata);
            
            if($updateacc_detailupdate){
                
            $table_student_issued_book_library_record='student_library_record';
            $wheredatastudent_detail = array('student_rollno' => $stu_roll_no);
            $fetch_stdnt_lib_detail=$this->select_fetch($wheredatastudent_detail,$table_student_issued_book_library_record); 
         
//            STEP 4
//            UPDATE STUDENT RECORD LIBRARY
            $issuebook_no_updated = $fetch_stdnt_lib_detail['no_of_book_issued']+1;
            $updatedata_ib_rec= array('no_of_book_issued'=> $issuebook_no_updated);
            $wheredata=array('student_rollno' => $stu_roll_no);
            $updatestudentlibrecord=$this->update_row($table_student_issued_book_library_record,$updatedata_ib_rec,$wheredata);
            
            if($updatestudentlibrecord){
                
//                STEP 5
//                Save All Data in BOOK Issue Return Table
              $bookissuedate=date('Y-m-d');
              $bookreturndate=date('Y-m-d', strtotime($bookissuedate. ' + 14 days'));
              $formArray=array('issued_to'=>$stu_roll_no,
                               'issued_to_type'=>'student',
                               'accession_book_id'=>$accession_book_id,
                               'date_of_issue'=>$bookissuedate,
                               'date_of_return'=>$bookreturndate,
                                        );  
              $table_lib_book_issue_return = 'lib_book_issue_return';  
              $lib_book_issue_return=$this->db->insert($table_lib_book_issue_return,$formArray); //Table Name And With fields
              return ($this->db->affected_rows($lib_book_issue_return) != 1) ? false : true;  
                
            }
            }
            
           }
           
        }
        
    }
    
//   Book Return 
    function returnbook($bookrow_id=''){
        $table_acc_booksstock='accession_books';
        $wheredataacc_book = array('accession_book_id'=>$bookrow_id);
        $checkresult=$this->select_fetch($wheredataacc_book,$table_acc_booksstock);
        print_r($checkresult);
        echo $getaccession_id=$checkresult['accession_detail_id'];
        echo $issued_to=$checkresult['issued_to'];
    }
    
    
    
    
    
    function select_fetch($data,$table){
        
        $query = $this->db->get_where($table,$data );
        $result = $query->row_array();
        if(!empty($result)){
            return $result;
        }else{
            return false;
        }
    }
    
    function update_row($table,$updatedata,$wheredata){
        
        
        $updatedrow=$this->db->update(
                $table,
                $updatedata,
                $wheredata
                );
        
        if($this->db->affected_rows($updatedrow)>0){
            return true;
        }else{
            return false;
        }
    }
    
    
    
 }