<?php 

class Model_category extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_products');
	}

	/* get active brand infromation */
	public function getActiveCategroy()
	{
		$sql = "SELECT * FROM categories WHERE active = ?";
		$query = $this->db->query($sql, array(1));
		return $query->result_array();
	}


	public function getCategroybyCategoryType($category_type)
	{
		if($category_type === "Restaurants"){
			$sql = "SELECT * FROM categories WHERE active = ? AND category_type_id = 3";
			$query = $this->db->query($sql, array(1));
			return $query->result_array();
		}
		elseif($category_type === "MisthanBakery"){
			$sql = "SELECT * FROM categories WHERE active = ? AND category_type_id != 3";
			$query = $this->db->query($sql, array(1));
			return $query->result_array();
		}
	}


	/* get the brand data */
	public function getCategoryData($id = null)
	{
		if($id) {
			$sql = "SELECT * FROM categories WHERE id = ?";
			$query = $this->db->query($sql, array($id));
			return $query->row_array();
		}

		$sql = "SELECT * FROM categories";
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	public function getCategoryDataByID($id = null)
	{
			$sql = "SELECT * FROM categories WHERE id = ?";
			$query = $this->db->query($sql, array($id));
			return $query->row();
	}

	public function create($data)
	{
		if($data) {
			$insert = $this->db->insert('categories', $data);
			return ($insert == true) ? true : false;
		}
	}

	public function update($data, $id)
	{
		if($data && $id) {
			$this->db->where('id', $id);
			$update = $this->db->update('categories', $data);
			return ($update == true) ? true : false;
		}
	}

	public function remove($id)
	{
		if($id) {
			$this->db->where('id', $id);
			$delete = $this->db->delete('categories');
			return ($delete == true) ? true : false;
		}
	}

	public function getProductbyCategory($query, $category_type)
	{
		// var_dump($category_type);
		// die;
		if($query === '' || $query === ' '){
			$index1=0;
			$categories = $this->getCategroybyCategoryType($category_type);
			if(isset($categories)){
				$product_avail_count = 0;
			foreach($categories as $category)
			{
			    $result = array();
				$products = $this->model_products->get_Product_Bycategory($category['id']);
				$pro_index = 0;
				foreach($products as $product){
					$quantity_unit=$this->model_products->get_quantity_pice($product['id']);
                    if(count($quantity_unit)>0)
                    {
                        $products[$pro_index]['quantity_price'] = $quantity_unit;
                        $unit_index =0;
    					foreach($quantity_unit as $units){
    						$quantity_units=$this->model_products->get_units($units['unit_id']);
    						$products[$pro_index]['quantity_price'][$unit_index]['unit_name']=$quantity_units->unit;
    						++$unit_index;
    					}
    					$result[] = $products[$pro_index];
                    }
					++$pro_index;
				}
				
				if(count($result)){
					
					++$product_avail_count;
					$categories[$index1]['products'] = $result;
					++$index1;
				}else{
					$categories[$index1]['products'] = NULL;
						++$index1;
				}
				
			}
			$categories['product_avail_count'] = $product_avail_count;
			return $categories;
			}
			
		}else if($query != '')
		{
			$index2=0;
			$categories = $this->getCategroybyCategoryType($category_type);
			$product_avail_count = 0;
			foreach($categories as $category)
			{
			    $result = array();
				$products = $this->model_products->get_search_Product_Bycategory($category['id'], $query);
				$pro_index = 0;
				foreach($products as $product){
					$products[$pro_index]['quantity_price']=$this->model_products->get_quantity_pice($product['id']);
					$quantity_unit=$products[$pro_index]['quantity_price'];

					if(count($quantity_unit)>0)
                    {
                        $products[$pro_index]['quantity_price'] = $quantity_unit;
                        $unit_index =0;
    					foreach($quantity_unit as $units){
    						$quantity_units=$this->model_products->get_units($units['unit_id']);
    						$products[$pro_index]['quantity_price'][$unit_index]['unit_name']=$quantity_units->unit;
    						++$unit_index;
    					}
    					$result[] = $products[$pro_index];
                    }
					++$pro_index;
				}
				if((int) count($result) > 0){
					++$product_avail_count;
					$categories[$index2]['products'] = $result;
						++$index2;
				}else{
					$categories[$index2]['products'] = NULL;
						++$index2;
				}
			}
			$categories['product_avail_count'] = $product_avail_count;
			return $categories;
		}
	}
	public function getProductbyPrice($price, $category_type)
	{
		
		if($price == NULL){
			$index1=0;
			$categories = $this->getCategroybyCategoryType($category_type);
			if(isset($categories)){
			$product_avail_count = 0;
			foreach($categories as $category)
			{
				$products = $this->model_products->get_Product_Bycategory($category['id']);
				$pro_index = 0;
				foreach($products as $product){
					$products[$pro_index]['quantity_price']=$this->model_products->get_quantity_pice($product['id']);
					$quantity_unit=$products[$pro_index]['quantity_price'];
					$unit_index =0;
					foreach($quantity_unit as $units){
						$quantity_units=$this->model_products->get_units($units['unit_id']);
						$products[$pro_index]['quantity_price'][$unit_index]['unit_name']=$quantity_units->unit;
						++$unit_index;
					}
					++$pro_index;
				}
				if(count($products)){
					++$product_avail_count;
					$categories[$index1]['products'] = $products;
					++$index1;
				}else{
					$categories[$index1]['products'] = NULL;
						++$index1;
				}
			}
			$categories['product_avail_count'] = $product_avail_count;
			return $categories;
		}
		}else{
			
			$index1=0;
			$ids = NULL;
			$prods = NULL;
			$product_avail_count = 0;
			$products = $this->model_products->getProductUnitPrice($price);
			$categories = $this->getCategroybyCategoryType($category_type);
			$pro_index = 0;
			foreach($products as $product){
				$ids[] = $product['id_products'];
				
			}
			$product_avail_count = 0;
			if($ids != NULL){
			$product_ids = array_unique($ids);
			foreach($product_ids as $id){
				$productData = $this->model_products->get_Product_By_Price($id);
				if($productData)
				{
				    $prods[]= $productData;
				}
			}
				// var_dump($prods);
			
			$index = 0;
			foreach($categories as $category){
				$pro_index = 0;
				foreach($prods as $prod){
				// 	var_dump($prod);
					// die;
					
						if($prod[0]['category_id'] == $category['id']){
							$p = $this->model_products->get_Product_By_Pro_id($prod[0]['id'],$category['id']);
							if(count($p)){
							$categories[$index]['products'][$pro_index] = $p[0];
							$quantity_unit = $this->model_products->get_quantity_pice($prod[0]['id']);
							
							$categories[$index]['products'][$pro_index]['quantity_price'] = $quantity_unit;
							$unit_index =0;
							foreach($quantity_unit as $units){
								$quantity_units=$this->model_products->get_units($units['unit_id']);
								$categories[$index]['products'][$pro_index]['quantity_price'][$unit_index]['unit_name']=$quantity_units->unit;
								++$unit_index;
							}
							++$pro_index;
							++$product_avail_count;
							}
						}
					}
					++$index;
				}
		}
		
			// var_dump($categories);
			// die;
			$categories['product_avail_count'] = $product_avail_count;
			return  $categories;
			// $products = $product_data;
			
		}
	}

	
	public function getActiveSellCategory()
	{
		$this->db->select('*');
		$this->db->from('category_type');
		$this->db->where('status',1);
		$query = $this->db->get();
		return $query->result();
	}

	public function getCategorybyCategoryType($id)
	{
		$this->db->select('*');
		$this->db->from('categories');
		$this->db->where('category_type_id', $id);
		$this->db->where('active',1);
		$query = $this->db->get();
		return $query->result();
	}

}