<?php

 class Operation_model extends CI_Model{
    //put your code here
    public function __construct() {
        parent::__construct();
    }
    
    //Get all record with order by
     public function getallList($tablename='',$orderfieldname='',$orderbycon='')
    { 
            //Get all record with order by
            $this->db->order_by($orderfieldname,$orderbycon); // Order by Condition
            $query =  $this->db->get($tablename); // Table Name Condition
            $result = $query->result_array();
            
            return !empty($result) ? $result : false; // Return Results
    }
    
    //Get List With Selected Field
    public function getallList_withfield($tablename='',$selectvalue=''){
        if(!empty($selectvalue)){
            $selectvalue=$selectvalue;
        }else{
            $selectvalue='*';
        }
        $this->db->select($selectvalue);
        $this->db->from($tablename);
        $query = $this->db->get();
        $result = $query->result_array();
        return !empty($result) ? $result : false;
    }
    
    //Get all row record with Where Condition
     public function get_allrecord_by_field($tablename='',$wherecausefield='',$wherecausedata='')
    {
         
        $this->db->select('*');
        $this->db->from($tablename);
        $this->db->where($wherecausefield,$wherecausedata);  // Also mention table name here
        $query = $this->db->get();    
        $result = $query->result_array();
        return !empty($result) ? $result : false; // Return Results
    }
     
     //Get single row record with Where Condition
     public function get_record_by_id($tablename='',$selectfield='',$wherecausefield='',$wherecausedata='')
    {
         
        $this->db->select($selectfield);
        $this->db->from($tablename);
        $this->db->where($wherecausefield,$wherecausedata);  // Also mention table name here
        $query = $this->db->get();    
        $result = $query->row();
        return !empty($result) ? $result : false; // Return Results
    }
     
    //Insert Into table with field 
     function insert_all($formArray,$tablename="") 
    {
           
            $this->db->insert($tablename,$formArray); //Table Name And With fields
            
            return ($this->db->affected_rows() != 1) ? false : true;
    }
    
    //Insert Into table with field 
     function insert_all_getlastid($formArray,$tablename="") 
    {
            
            $this->db->insert($tablename,$formArray); //Table Name And With fields
            $insert_id = $this->db->insert_id(); //Get Last Inserted ID
            
            return ($insert_id > 0) ? $insert_id : false;
    }
    
    function update_all($categoryidfield="",$categoryid="",$formArray,$tablename=""){
        $this->db->where($categoryidfield, $categoryid);
        $this->db->update($tablename, $formArray);

          return ($this->db->affected_rows() != 1) ? false : true;
    }
    
    
    
    function search_like($table,$field,$title){
        
        $this->db->like($field, $title , 'both');
        $this->db->order_by($field, 'ASC');
        
        return $this->db->get($table)->result();
 
    }
    

    
 }
?>

