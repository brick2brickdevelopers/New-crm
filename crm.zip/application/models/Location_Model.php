<?php  

class Location_Model extends CI_Model {  
    
    public function __construct() {
        parent::__construct();
        
    }
    
    
    function getCityData(){
        $this->db->select('cities.*');
        $this->db->from('cities');
        $this->db->where('country_id','101');         
        $query = $this->db->get();
        $result = $query->result_array();
        return !empty($result) ? $result : false;
    }
    
    function get_CityData_by_id($id){
        $this->db->select('cities.*');
        $this->db->from('cities');
        $this->db->where('id',$id);  // Also mention table name here
        $query = $this->db->get();    
        $result = $query->row();
        return !empty($result) ? $result : false; // Return Results
    }
    
}