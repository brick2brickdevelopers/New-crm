<?php  

class User_model extends CI_Model {  
    
    public function __construct() {
        parent::__construct();
        
    }
    
    
    function createUser($formArray){
        $this->db->insert('users',$formArray); //Table Name And With fields
        $insert_id = $this->db->insert_id(); //Get Last Inserted ID
        return ($insert_id > 0) ? $insert_id : false;
    }
    
    function createUserLogin($formArray){
        $this->db->insert('tbl_users',$formArray); //Table Name And With fields
        $insert_id = $this->db->insert_id(); //Get Last Inserted ID
        return ($insert_id > 0) ? $insert_id : false;
    }
    
    function updateUser($formArray,$id){
        $this->db->where('ur_id',$id);  // Also mention table name here
        $this->db->update('users',$formArray);
        return ($this->db->affected_rows() != 1) ? false : true;
    }
    
    function updateUserLogin($formArray,$id){
        $this->db->where('acc_id',$id);  // Also mention table name here
        $this->db->update('tbl_users',$formArray);
        return ($this->db->affected_rows() != 1) ? false : true;
    }
    
    
    //Insert Into table with field 
     function remove($id) 
    {
           $this->db->where('stages_id',$id);  // Also mention table name here
           $this->db->delete('users');
           return ($this->db->affected_rows() != 1) ? false : true;
    }
    
    function getData(){

//ur_branch
//ur_branchmanger
//ur_contact
//ur_createdby
//ur_createddate
//ur_createrrole
//ur_email
//ur_id
//ur_isactive
//ur_isdeleted
//ur_joindate
//ur_name
//ur_role
//ur_teamlead
        
        
        
        
        
        
        
        
        
        
        $this->db->select('users.*');
        $this->db->from('users');
//        $this->db->join('tbl_users','users.stage_createrid=tbl_users.user_id');
//        $this->db->join('user_level','users.stage_createrole=user_level.ul_rowid');
//        $this->db->order_by("users.stages_id", "desc");
        $query = $this->db->get();
        $result = $query->result_array();
        return !empty($result) ? $result : false;
    }
    
    function get_Data_by_id($id){
        $this->db->select('stages.*,tbl_users.user_name,user_level.ul_title');
        $this->db->from('stages');
        $this->db->join('tbl_users','stages.stage_createrid=tbl_users.user_id');
        $this->db->join('user_level','stages.stage_createrole=user_level.ul_rowid');
        $this->db->where('stages_id',$id);  // Also mention table name here
        $query = $this->db->get();    
        $result = $query->row();
        return !empty($result) ? $result : false; // Return Results
    }
    
}