<?php  

class Stages_model extends CI_Model {  
    
    public function __construct() {
        parent::__construct();
        
    }
    
    //Insert Into table with field 
     function insert($formArray) 
    {
            $this->db->insert('stages',$formArray); //Table Name And With fields
            $insert_id = $this->db->insert_id(); //Get Last Inserted ID
            return ($insert_id > 0) ? $insert_id : false;
    }
    
    //Insert Into table with field 
     function update($formArray,$id) 
    {
           $this->db->where('stages_id',$id);  // Also mention table name here
           $this->db->update('stages',$formArray);
           return ($this->db->affected_rows() != 1) ? false : true;
    }
    
    //Insert Into table with field 
     function remove($id) 
    {
           $this->db->where('stages_id',$id);  // Also mention table name here
           $this->db->delete('stages');
           return ($this->db->affected_rows() != 1) ? false : true;
    }
    
    function getData(){
        $this->db->select('stages.*,tbl_users.user_name,user_level.ul_title');
        $this->db->from('stages');
        $this->db->join('tbl_users','stages.stage_createrid=tbl_users.user_id');
        $this->db->join('user_level','stages.stage_createrole=user_level.ul_rowid');
        $this->db->order_by("stages.stages_id", "desc");
        $query = $this->db->get();
        $result = $query->result_array();
        return !empty($result) ? $result : false;
    }
    
    function get_Data_by_id($id){
        $this->db->select('stages.*,tbl_users.user_name,user_level.ul_title');
        $this->db->from('stages');
        $this->db->join('tbl_users','stages.stage_createrid=tbl_users.user_id');
        $this->db->join('user_level','stages.stage_createrole=user_level.ul_rowid');
        $this->db->where('stages_id',$id);  // Also mention table name here
        $query = $this->db->get();    
        $result = $query->row();
        return !empty($result) ? $result : false; // Return Results
    }
    
}