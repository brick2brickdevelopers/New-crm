<?php  

class Login_model extends CI_Model {  

            function login($data)
            {
             $this->db->select('*');
             $this->db->from('tbl_users');
             $this->db->where('user_email', $data['email_id']);
             $this->db->where('acc_status', 1);
             $this->db->where('acc_deleted', 1);
             $query = $this->db->get();
             
            if($query->num_rows() > 0)
                {
                    $user = $query->row();
                    $encryptedpassword=md5($data['password']);
                   
				if($encryptedpassword === $user->user_password) {
					return $user;	
				}
				else {
					return false;
				}
                }
                else
                {
                    return false;
                }
            }
            
            
    
}